package com.bean;
public class GoodsBean {

    private int Goods_Id ;
    private String Goods_Name ;
    private String Goods_Type ;
    private String Goods_Unit ;
    private int Goods_Price;
    private int Goods_Warehouse;
    private int Goods_Bar;
	public int getGoods_Id() {
		return Goods_Id;
	}
	public void setGoods_Id(int goods_Id) {
		Goods_Id = goods_Id;
	}
	public String getGoods_Name() {
		return Goods_Name;
	}
	public void setGoods_Name(String goods_Name) {
		Goods_Name = goods_Name;
	}
	public String getGoods_Type() {
		return Goods_Type;
	}
	public void setGoods_Type(String goods_Type) {
		Goods_Type = goods_Type;
	}
	
	public String getGoods_Unit() {
		return Goods_Unit;
	}
	public void setGoods_Unit(String goods_Unit) {
		Goods_Unit = goods_Unit;
	}
	public int getGoods_Price() {
		return Goods_Price;
	}
	public void setGoods_Price(int goods_Price) {
		Goods_Price = goods_Price;
	}
	public int getGoods_Warehouse() {
		return Goods_Warehouse;
	}
	public void setGoods_Warehouse(int goods_Warehouse) {
		Goods_Warehouse = goods_Warehouse;
	}
	public int getGoods_Bar() {
		return Goods_Bar;
	}
	public void setGoods_Bar(int goods_Bar) {
		Goods_Bar = goods_Bar;
	}
    
    
}