package com.bean;

public class GReturnBean {
	private int GReturn_Id;
	private String GReturn_Name;
	private String GReturn_Type;
	private String GReturn_Unit;
	private int GReturn_Cost;
	private int GReturn_Pro ;
	private int GReturn_Num;
	private String GReturn_Time;
	
	public int getGReturn_Id() {
		return GReturn_Id;
	}
	public void setGReturn_Id(int gStock_Id) {
		GReturn_Id = gStock_Id;
	}
	public String getGReturn_Name() {
		return GReturn_Name;
	}
	public void setGReturn_Name(String gStock_Name) {
		GReturn_Name = gStock_Name;
	}
	public String getGReturn_Type() {
		return GReturn_Type;
	}
	
	public String getGReturn_Unit() {
		return GReturn_Unit;
	}
	public void setGReturn_Unit(String gStock_Unit) {
		GReturn_Unit = gStock_Unit;
	}
	public int getGReturn_Cost() {
		return GReturn_Cost;
	}
	public void setGReturn_Cost(int gStock_Cost) {
		GReturn_Cost = gStock_Cost;
	}
	public int getGReturn_Pro() {
		return GReturn_Pro;
	}
	public void setGReturn_Pro(int gStock_Pro) {
		GReturn_Pro = gStock_Pro;
	}
	public void setGReturn_Type(String gStock_Type) {
		GReturn_Type = gStock_Type;
	}
	public int getGReturn_Num() {
		return GReturn_Num;
	}
	public void setGReturn_Num(int gStock_Num) {
		GReturn_Num = gStock_Num;
	}
	public String getGReturn_Time() {
		return GReturn_Time;
	}
	public void setGReturn_Time(String gStock_Time) {
		GReturn_Time = gStock_Time;
	}
	
}
