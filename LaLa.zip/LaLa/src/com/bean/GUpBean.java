package com.bean;

public class GUpBean {
	private int GUp_Id;
	private String GUp_Name;
	private String GUp_Type;
	private String GUp_Unit;
	private int GUp_Twarehouse;
	private int GUp_Tbar;
	private int GUp_Num;
	private String GUp_Time;
	public int getGUp_Id() {
		return GUp_Id;
	}
	public void setGUp_Id(int gUp_Id) {
		GUp_Id = gUp_Id;
	}
	public String getGUp_Name() {
		return GUp_Name;
	}
	public void setGUp_Name(String gUp_Name) {
		GUp_Name = gUp_Name;
	}
	public String getGUp_Type() {
		return GUp_Type;
	}
	public void setGUp_Type(String gUp_Type) {
		GUp_Type = gUp_Type;
	}
	public String getGUp_Unit() {
		return GUp_Unit;
	}
	public void setGUp_Unit(String gUp_Unit) {
		GUp_Unit = gUp_Unit;
	}
	
	public int getGUp_Twarehouse() {
		return GUp_Twarehouse;
	}
	public void setGUp_Twarehouse(int gUp_Twarehouse) {
		GUp_Twarehouse = gUp_Twarehouse;
	}
	public int getGUp_Tbar() {
		return GUp_Tbar;
	}
	public void setGUp_Tbar(int gUp_Tbar) {
		GUp_Tbar = gUp_Tbar;
	}
	public int getGUp_Num() {
		return GUp_Num;
	}
	public void setGUp_Num(int gUp_Num) {
		GUp_Num = gUp_Num;
	}
	public String getGUp_Time() {
		return GUp_Time;
	}
	public void setGUp_Time(String gUp_Time) {
		GUp_Time = gUp_Time;
	}

	
}
