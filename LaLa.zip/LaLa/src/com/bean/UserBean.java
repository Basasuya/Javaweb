package com.bean;

public class UserBean {
	private String name;  
    private Integer profit;  
   
      
    public Integer getProfit() {
		return profit;
	}
	public void setProfit(Integer profit) {
		this.profit = profit;
	}
	public String getName() {  
        return name;  
    }  
    public void setName(String name) {  
        this.name = name;  
    }
}
