package com.bean;
public class AdrecordBean {
    private String Adrecord_Username ;
    private String Adrecord_Time ;
    private int Adrecord_Id;
    
	public String getAdrecord_Username() {
		return Adrecord_Username;
	}
	public void setAdrecord_Username(String adrecord_Username) {
		Adrecord_Username = adrecord_Username;
	}
	public String getAdrecord_Time() {
		return Adrecord_Time;
	}
	public void setAdrecord_Time(String adrecord_Time) {
		Adrecord_Time = adrecord_Time;
	}
	public int getAdrecord_Id() {
		return Adrecord_Id;
	}
	public void setAdrecord_Id(int adrecord_Id) {
		Adrecord_Id = adrecord_Id;
	}
    
	
	
}
