package com.bean;

public class BBuyBean {
	private int BBuy_Id;
	private String BBuy_Name;
	private String BBuy_Type;
	private String BBuy_Unit;
	private int BBuy_Pro;
	private int BBuy_Num;
	private String BBuy_Time;
	
	public int getBBuy_Id() {
		return BBuy_Id;
	}
	public void setBBuy_Id(int gBuy_Id) {
		BBuy_Id = gBuy_Id;
	}
	public String getBBuy_Name() {
		return BBuy_Name;
	}
	public void setBBuy_Name(String gBuy_Name) {
		BBuy_Name = gBuy_Name;
	}
	public String getBBuy_Type() {
		return BBuy_Type;
	}
	public void setBBuy_Type(String gBuy_Type) {
		BBuy_Type = gBuy_Type;
	}
	
	public String getBBuy_Unit() {
		return BBuy_Unit;
	}
	public void setBBuy_Unit(String gBuy_Unit) {
		BBuy_Unit = gBuy_Unit;
	}
	public int getBBuy_Pro() {
		return BBuy_Pro;
	}
	public void setBBuy_Pro(int gBuy_Pro) {
		BBuy_Pro = gBuy_Pro;
	}
	public int getBBuy_Num() {
		return BBuy_Num;
	}
	public void setBBuy_Num(int gBuy_Num) {
		BBuy_Num = gBuy_Num;
	}
	public String getBBuy_Time() {
		return BBuy_Time;
	}
	public void setBBuy_Time(String gBuy_Time) {
		BBuy_Time = gBuy_Time;
	}
	
	
}
