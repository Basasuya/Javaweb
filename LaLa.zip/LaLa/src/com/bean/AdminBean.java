package com.bean;
public class AdminBean {
    private String Admin_Username ;
    private String Admin_Password ;
    private int Admin_Id;
    
	public String getAdmin_Username() {
		return Admin_Username;
	}
	public void setAdmin_Username(String admin_Username) {
		Admin_Username = admin_Username;
	}
	public String getAdmin_Password() {
		return Admin_Password;
	}
	public void setAdmin_Password(String admin_Password) {
		Admin_Password = admin_Password;
	}
	public int getAdmin_Id() {
		return Admin_Id;
	}
	public void setAdmin_Id(int admin_Id) {
		Admin_Id = admin_Id;
	}
	
}
