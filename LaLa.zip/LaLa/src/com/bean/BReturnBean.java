package com.bean;

public class BReturnBean {
	private int BReturn_Id;
	private String BReturn_Name;
	private String BReturn_Type;
	private String BReturn_Unit;
	private int BReturn_Cost;
	private int BReturn_Pro ;
	private int BReturn_Num;
	private String BReturn_Time;
	
	public int getBReturn_Id() {
		return BReturn_Id;
	}
	public void setBReturn_Id(int gStock_Id) {
		BReturn_Id = gStock_Id;
	}
	public String getBReturn_Name() {
		return BReturn_Name;
	}
	public void setBReturn_Name(String gStock_Name) {
		BReturn_Name = gStock_Name;
	}
	public String getBReturn_Type() {
		return BReturn_Type;
	}
	
	public String getBReturn_Unit() {
		return BReturn_Unit;
	}
	public void setBReturn_Unit(String gStock_Unit) {
		BReturn_Unit = gStock_Unit;
	}
	public int getBReturn_Cost() {
		return BReturn_Cost;
	}
	public void setBReturn_Cost(int gStock_Cost) {
		BReturn_Cost = gStock_Cost;
	}
	public int getBReturn_Pro() {
		return BReturn_Pro;
	}
	public void setBReturn_Pro(int gStock_Pro) {
		BReturn_Pro = gStock_Pro;
	}
	public void setBReturn_Type(String gStock_Type) {
		BReturn_Type = gStock_Type;
	}
	public int getBReturn_Num() {
		return BReturn_Num;
	}
	public void setBReturn_Num(int gStock_Num) {
		BReturn_Num = gStock_Num;
	}
	public String getBReturn_Time() {
		return BReturn_Time;
	}
	public void setBReturn_Time(String gStock_Time) {
		BReturn_Time = gStock_Time;
	}
	
}
