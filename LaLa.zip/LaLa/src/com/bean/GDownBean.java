package com.bean;

public class GDownBean {
	private int GDown_Id;
	private String GDown_Name;
	private String GDown_Type;
	private String GDown_Unit;
	private int GDown_Twarehouse;
	private int GDown_Tbar;
	private int GDown_Num;
	private String GDown_Time;
	
	public int getGDown_Id() {
		return GDown_Id;
	}
	public void setGDown_Id(int gDown_Id) {
		GDown_Id = gDown_Id;
	}
	public String getGDown_Name() {
		return GDown_Name;
	}
	public void setGDown_Name(String gDown_Name) {
		GDown_Name = gDown_Name;
	}
	public String getGDown_Type() {
		return GDown_Type;
	}
	public void setGDown_Type(String gDown_Type) {
		GDown_Type = gDown_Type;
	}
	public String getGDown_Unit() {
		return GDown_Unit;
	}
	public void setGDown_Unit(String gDown_Unit) {
		GDown_Unit = gDown_Unit;
	}
	public int getGDown_Twarehouse() {
		return GDown_Twarehouse;
	}
	public void setGDown_Twarehouse(int gDown_Twarehouse) {
		GDown_Twarehouse = gDown_Twarehouse;
	}
	public int getGDown_Tbar() {
		return GDown_Tbar;
	}
	public void setGDown_Tbar(int gDown_Tbar) {
		GDown_Tbar = gDown_Tbar;
	}
	public int getGDown_Num() {
		return GDown_Num;
	}
	public void setGDown_Num(int gDown_Num) {
		GDown_Num = gDown_Num;
	}
	public String getGDown_Time() {
		return GDown_Time;
	}
	public void setGDown_Time(String gDown_Time) {
		GDown_Time = gDown_Time;
	}



	
}
