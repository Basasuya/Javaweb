package com.bean;
public class BoodsBean {

    private int Boods_Id ;
    private String Boods_Name ;
    private String Boods_Type ;
    private String Boods_Unit ;
    private int Boods_Price;
    private int Boods_Warehouse;
    private int Boods_Bar;
	public int getBoods_Id() {
		return Boods_Id;
	}
	public void setBoods_Id(int goods_Id) {
		Boods_Id = goods_Id;
	}
	public String getBoods_Name() {
		return Boods_Name;
	}
	public void setBoods_Name(String goods_Name) {
		Boods_Name = goods_Name;
	}
	public String getBoods_Type() {
		return Boods_Type;
	}
	public void setBoods_Type(String goods_Type) {
		Boods_Type = goods_Type;
	}
	
	public String getBoods_Unit() {
		return Boods_Unit;
	}
	public void setBoods_Unit(String goods_Unit) {
		Boods_Unit = goods_Unit;
	}
	public int getBoods_Price() {
		return Boods_Price;
	}
	public void setBoods_Price(int goods_Price) {
		Boods_Price = goods_Price;
	}
	public int getBoods_Warehouse() {
		return Boods_Warehouse;
	}
	public void setBoods_Warehouse(int goods_Warehouse) {
		Boods_Warehouse = goods_Warehouse;
	}
	public int getBoods_Bar() {
		return Boods_Bar;
	}
	public void setBoods_Bar(int goods_Bar) {
		Boods_Bar = goods_Bar;
	}
    
    
}