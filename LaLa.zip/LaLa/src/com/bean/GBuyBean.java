package com.bean;

public class GBuyBean {
	private int GBuy_Id;
	private String GBuy_Name;
	private String GBuy_Type;
	private String GBuy_Unit;
	private int GBuy_Pro;
	private int GBuy_Num;
	private String GBuy_Time;
	
	public int getGBuy_Id() {
		return GBuy_Id;
	}
	public void setGBuy_Id(int gBuy_Id) {
		GBuy_Id = gBuy_Id;
	}
	public String getGBuy_Name() {
		return GBuy_Name;
	}
	public void setGBuy_Name(String gBuy_Name) {
		GBuy_Name = gBuy_Name;
	}
	public String getGBuy_Type() {
		return GBuy_Type;
	}
	public void setGBuy_Type(String gBuy_Type) {
		GBuy_Type = gBuy_Type;
	}
	
	public String getGBuy_Unit() {
		return GBuy_Unit;
	}
	public void setGBuy_Unit(String gBuy_Unit) {
		GBuy_Unit = gBuy_Unit;
	}
	public int getGBuy_Pro() {
		return GBuy_Pro;
	}
	public void setGBuy_Pro(int gBuy_Pro) {
		GBuy_Pro = gBuy_Pro;
	}
	public int getGBuy_Num() {
		return GBuy_Num;
	}
	public void setGBuy_Num(int gBuy_Num) {
		GBuy_Num = gBuy_Num;
	}
	public String getGBuy_Time() {
		return GBuy_Time;
	}
	public void setGBuy_Time(String gBuy_Time) {
		GBuy_Time = gBuy_Time;
	}
	
	
}
