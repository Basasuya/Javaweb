package com.bean;

public class BUpBean {
	private int BUp_Id;
	private String BUp_Name;
	private String BUp_Type;
	private String BUp_Unit;
	private int BUp_Twarehouse;
	private int BUp_Tbar;
	private int BUp_Num;
	private String BUp_Time;
	public int getBUp_Id() {
		return BUp_Id;
	}
	public void setBUp_Id(int gUp_Id) {
		BUp_Id = gUp_Id;
	}
	public String getBUp_Name() {
		return BUp_Name;
	}
	public void setBUp_Name(String gUp_Name) {
		BUp_Name = gUp_Name;
	}
	public String getBUp_Type() {
		return BUp_Type;
	}
	public void setBUp_Type(String gUp_Type) {
		BUp_Type = gUp_Type;
	}
	public String getBUp_Unit() {
		return BUp_Unit;
	}
	public void setBUp_Unit(String gUp_Unit) {
		BUp_Unit = gUp_Unit;
	}
	
	public int getBUp_Twarehouse() {
		return BUp_Twarehouse;
	}
	public void setBUp_Twarehouse(int gUp_Twarehouse) {
		BUp_Twarehouse = gUp_Twarehouse;
	}
	public int getBUp_Tbar() {
		return BUp_Tbar;
	}
	public void setBUp_Tbar(int gUp_Tbar) {
		BUp_Tbar = gUp_Tbar;
	}
	public int getBUp_Num() {
		return BUp_Num;
	}
	public void setBUp_Num(int gUp_Num) {
		BUp_Num = gUp_Num;
	}
	public String getBUp_Time() {
		return BUp_Time;
	}
	public void setBUp_Time(String gUp_Time) {
		BUp_Time = gUp_Time;
	}

	
}
