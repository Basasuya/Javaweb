package com.bean;

public class GStockBean {
	private int GStock_Id;
	private String GStock_Name;
	private String GStock_Type;
	private String GStock_Unit;
	private int GStock_Cost;
	private int GStock_Pro ;
	private int GStock_Num;
	private String GStock_Time;
	
	public int getGStock_Id() {
		return GStock_Id;
	}
	public void setGStock_Id(int gStock_Id) {
		GStock_Id = gStock_Id;
	}
	public String getGStock_Name() {
		return GStock_Name;
	}
	public void setGStock_Name(String gStock_Name) {
		GStock_Name = gStock_Name;
	}
	public String getGStock_Type() {
		return GStock_Type;
	}
	
	public String getGStock_Unit() {
		return GStock_Unit;
	}
	public void setGStock_Unit(String gStock_Unit) {
		GStock_Unit = gStock_Unit;
	}
	public int getGStock_Cost() {
		return GStock_Cost;
	}
	public void setGStock_Cost(int gStock_Cost) {
		GStock_Cost = gStock_Cost;
	}
	public int getGStock_Pro() {
		return GStock_Pro;
	}
	public void setGStock_Pro(int gStock_Pro) {
		GStock_Pro = gStock_Pro;
	}
	public void setGStock_Type(String gStock_Type) {
		GStock_Type = gStock_Type;
	}
	public int getGStock_Num() {
		return GStock_Num;
	}
	public void setGStock_Num(int gStock_Num) {
		GStock_Num = gStock_Num;
	}
	public String getGStock_Time() {
		return GStock_Time;
	}
	public void setGStock_Time(String gStock_Time) {
		GStock_Time = gStock_Time;
	}
	
}
