package com.bean;

public class BStockBean {
	private int BStock_Id;
	private String BStock_Name;
	private String BStock_Type;
	private String BStock_Unit;
	private int BStock_Cost;
	private int BStock_Pro ;
	private int BStock_Num;
	private String BStock_Time;
	
	public int getBStock_Id() {
		return BStock_Id;
	}
	public void setBStock_Id(int gStock_Id) {
		BStock_Id = gStock_Id;
	}
	public String getBStock_Name() {
		return BStock_Name;
	}
	public void setBStock_Name(String gStock_Name) {
		BStock_Name = gStock_Name;
	}
	public String getBStock_Type() {
		return BStock_Type;
	}
	
	public String getBStock_Unit() {
		return BStock_Unit;
	}
	public void setBStock_Unit(String gStock_Unit) {
		BStock_Unit = gStock_Unit;
	}
	public int getBStock_Cost() {
		return BStock_Cost;
	}
	public void setBStock_Cost(int gStock_Cost) {
		BStock_Cost = gStock_Cost;
	}
	public int getBStock_Pro() {
		return BStock_Pro;
	}
	public void setBStock_Pro(int gStock_Pro) {
		BStock_Pro = gStock_Pro;
	}
	public void setBStock_Type(String gStock_Type) {
		BStock_Type = gStock_Type;
	}
	public int getBStock_Num() {
		return BStock_Num;
	}
	public void setBStock_Num(int gStock_Num) {
		BStock_Num = gStock_Num;
	}
	public String getBStock_Time() {
		return BStock_Time;
	}
	public void setBStock_Time(String gStock_Time) {
		BStock_Time = gStock_Time;
	}
	
}
