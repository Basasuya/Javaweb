package com.bean;

public class ProfitBean {
	private int Profit_Id;
	private String Profit_Username;
	private int Profit_Gain;
	private String Profit_Time;
	
	
	public int getProfit_Id() {
		return Profit_Id;
	}
	public void setProfit_Id(int profit_Id) {
		Profit_Id = profit_Id;
	}
	public String getProfit_Username() {
		return Profit_Username;
	}
	public void setProfit_Username(String profit_Username) {
		Profit_Username = profit_Username;
	}
	public int getProfit_Gain() {
		return Profit_Gain;
	}
	public void setProfit_Gain(int profit_Gain) {
		Profit_Gain = profit_Gain;
	}
	public String getProfit_Time() {
		return Profit_Time;
	}
	public void setProfit_Time(String profit_Time) {
		Profit_Time = profit_Time;
	}
}
